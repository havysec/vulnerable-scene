<html>
<head>
<title>
</title>
</head>
<body>
<div align="right">
<a style="font-size:.8em;color:#FFFF00" href='index.php'><img src="../images/Home.png" height='45'; width='45'></a>
</div>
<center>
YOU ARE LOGGED IN
</center>
</body>
</html>
