#/bin/bash
#apt-get install mysql-server -y


chown -R root:root /var/www/html

chmod -R 755 /var/www/html

#mysql -e "update mysql.user set password=PASSWORD('R00tYHjkIf') where user='root';"


rm -f /var/www/html/mysql.sh
