#/bin/bash
container="burpsuite"
docker stop $container && docker rm $container

docker run -itd --name $container -p20002:80 $container
docker exec -it $container bash /var/www/html/mysql.sh

#./mysql.sh       root
