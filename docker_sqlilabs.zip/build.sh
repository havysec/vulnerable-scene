#/bin/bash
image="burpsuite"
docker build -t $image .
