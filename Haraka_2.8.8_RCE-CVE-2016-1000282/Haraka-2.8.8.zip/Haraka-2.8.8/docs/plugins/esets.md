esets
-----

This plugin allows virus scanning with ESET Mail Security for Linux/BSD.

Install the software as per the intructions from ESET and enable this plugin
and it will scan each message using the "esets_cli" command which defaults to
/opt/eset/esets/bin/esets_cli.
