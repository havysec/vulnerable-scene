rcpt\_to.max\_count
=================

This plugin sets a maximum limit on RCPT TOs. Violators will be disconnected.

Configuration
-------------

* rcpt\_to.max\_count

  The maximum number of recipients. Default: 40.
