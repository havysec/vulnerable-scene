queue/deliver
=============

This plugin is now redundant. Outbound delivery is now built into Haraka.