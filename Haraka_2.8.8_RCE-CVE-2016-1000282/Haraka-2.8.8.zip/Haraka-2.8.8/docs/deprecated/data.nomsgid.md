data.nomsgid
============

NOTICE: this plugin is deprecated. Use data.headers instead.

Quite simply enabling this plugin blocks all mails lacking a Message-Id
header. This is an aggressive anti-spam measure, but since most mail systems
will add a Message-Id header, it tends to block a good chunk of abusive mail.
