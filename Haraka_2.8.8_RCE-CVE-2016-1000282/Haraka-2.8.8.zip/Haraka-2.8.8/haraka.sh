#!/bin/sh
exec haraka -c /usr/local/haraka 2>&1
