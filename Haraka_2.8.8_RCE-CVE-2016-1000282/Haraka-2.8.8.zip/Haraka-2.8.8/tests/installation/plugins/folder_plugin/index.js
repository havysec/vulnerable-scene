"use strict";

exports.register = function () {
}
