"use strict";

exports.check_the_base = function () {
    return "base";
}
