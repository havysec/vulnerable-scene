<?php
/**
 * Ce fichier n'est la que pour eviter une rupture de compat depuis spip 3.0 pour les plugins
 */

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

include_spip('inc/filtres_selecteur_generique');
