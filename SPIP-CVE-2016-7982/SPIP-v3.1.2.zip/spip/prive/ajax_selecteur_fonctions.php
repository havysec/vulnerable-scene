<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

include_spip('formulaires/selecteur/generique_fonctions');
