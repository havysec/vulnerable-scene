#!/bin/bash

cp -rf ./bin/* /var/www/html/

sed -i "s/xxxxxx/$1/" /var/www/html/flag.php

sudo chown www-data:www-data -R /var/www/html/

chmod -R 755 /var/www/html

