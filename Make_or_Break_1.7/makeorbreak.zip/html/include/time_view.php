<?php
//echo date("Y-m-d H:i:s");
echo "<center><b>";
echo date("Y-m-d");
echo "<br>";
echo date("H:i:s");
echo "</b></center>";
?>