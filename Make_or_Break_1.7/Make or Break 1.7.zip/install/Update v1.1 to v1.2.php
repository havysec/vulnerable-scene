ALTER TABLE `mob_settings` ADD `advertishing2` TEXT NOT NULL;

ALTER TABLE `mob_images` ADD `img_description` TEXT NOT NULL;
ALTER TABLE `mob_uploads` ADD `upl_description` TEXT NOT NULL;