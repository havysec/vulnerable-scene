Open "include/header.php"

Search for:
	<a href="index.php">Main page</a><br>

Insert after:
	<a href="search.php">Search</a><br>