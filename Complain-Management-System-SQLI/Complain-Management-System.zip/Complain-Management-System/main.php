<p align="center" style="color:#990000;font-size:16px;font-weight:bold;" >Complain Management System</p>
<img src="images/make-online-complaint-btn.jpg"  style="float:left;border:0px; padding:10px;"/>
<p align="left" style="line-height:24px; padding:10px;"><b>Online Complaint Monitoring System (OCMS)</b> is a system operated by the city of Pune, India. A Complaint Management System is one of latest productivity enhancement tools used widely by all organisations wherever there is a need of booking of complaints via operators and analysis of complaints which are made or are pending.
<br/><br/>
Lack of paper movements provides complaint management operations a speed which was never envisaged in manual mode at all. Software allows a booking operator to book and lodge complaints and automatically schedules and prompts operators to source complaint to concerned departments. State of the art management information reports on complaint details and pending complaints with reasons and remarks provides management a better insight to problems and traffic situations of telephone lines. A never before �Report Wizard� not only allows you to define specific reports on demand but also allows you to define your own sorting and analysis parameters which may be more relevant to you but not programmed by us till now.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
