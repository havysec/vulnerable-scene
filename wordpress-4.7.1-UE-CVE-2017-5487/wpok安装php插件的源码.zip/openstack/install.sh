#!/bin/bash

sudo apt-get update

#sudo apt-get install -y apache2 php5 php-zip php-mbstring

#apt-get install -y --force-yes php5-mysql php5-dev php5-gd php5-memcache php5-pspell php5-snmp snmp php5-xmlrpc libapache2-mod-php5 php5-cli unzip wget exim4

ln -s /etc/apache2/mods-available/rewrite.load /etc/apache2/mods-enabled/

rm /var/www/html/index.html

rm /etc/apache2/sites-enabled/000-default.conf

rm /var/www/html/.htaccess

rm /etc/apache2/apache2.conf

cp -rf ./bin/* /var/www/html/

chmod -R 755 /var/www/html/*

mv /var/www/html/flag.txt /flag.txt

mv /var/www/html/htaccess.txt /var/www/html/.htaccess

mv /var/www/html/000-default.conf /etc/apache2/sites-enabled/

mv /var/www/html/wp /usr/bin/

chmod a+x /usr/bin/wp

sudo a2enmod rewrite

mv /var/www/html/apache2.conf /etc/apache2/apache2.conf

sudo service apache2 restart









