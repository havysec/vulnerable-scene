#!/bin/bash

sed -i "s/xxxxxx/$1/" /flag.txt

sudo chown www-data:www-data -R /var/www/html/

mysql -e "source /var/www/html/sql.sql"

rm /var/www/html/sql.sql

sudo service apache2 restart